function r = p2r(p)
% P2R - From image to kernel representation.
% P2R(P) is a minimal kernel representation of ker(R).

r = null(p')';