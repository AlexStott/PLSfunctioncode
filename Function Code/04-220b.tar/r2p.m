function p = r2p(r)
% R2P - From kernel to image representation.
% R2P(R) is a minimal image representation of ker(R).

p = null(r);